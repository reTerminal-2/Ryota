local player = game.Players.LocalPlayer
local Url = "https://www.roblox.com/headshot-thumbnail/image?userId=" .. player.UserId .. "&width=100&height=100&format=png"

local Exec
if identifyexecutor then
	Exec = tostring(identifyexecutor())
elseif getexecutor then
    Exec = tostring(getexecutor())
else
    Exec = "getexecutor/identifyexecutor Function Faliure."
end
game:GetService("StarterGui"):SetCore("SendNotification", {
    Title = "Ryota injector",
    Text = "Ryota Injected. Powered by Nezur.", 
    Icon = Url,     Duration = 40,
    Button1 = "Done", 
})